import React, { useState } from "react";
import { Form, Input, Select, Button, Steps, Tabs, Card, Row, Col } from "antd";
import { RightOutlined, LeftOutlined } from "@ant-design/icons";

const { Step } = Steps;
const { Option } = Select;
const { TabPane } = Tabs;

const PropertyManager = () => {
  const [currentTab, setCurrentTab] = useState("1");

  const handleNext = () => {
    setCurrentTab((prev) => (parseInt(prev) + 1).toString());
  };

  const handleBack = () => {
    setCurrentTab((prev) => (parseInt(prev) - 1).toString());
  };

  return (
    <div style={{ }}>
      {/* Breadcrumb */}
      <p style={{ marginBottom: 10, fontSize: 14, color: "#666" }}>
        <a href="#">Home</a> &gt; <a href="#">Properties</a> &gt;{" "}
        <span style={{ color: "#1890ff" }}>Property Manager</span>
      </p>

      {/* Steps Component */}
      <Steps current={parseInt(currentTab) - 1} style={{ marginBottom: 20 }}>
        <Step title="Property Details" />
        <Step title="Address Details" />
        <Step title="Pricing" />
        <Step title="Amenities" />
        <Step title="Documentation" />
        <Step title="Media" />
      </Steps>

      {/* Tabs Component */}
      <Tabs activeKey={currentTab} onChange={setCurrentTab} centered>
        <TabPane tab={<span>1 Property Details</span>} key="1">
          <Card>
            <Form layout="vertical">
              <Row gutter={16}>
                <Col span={8}>
                  <Form.Item label="Property Name">
                    <Input placeholder="Enter property name" />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Property Type">
                    <Select placeholder="Select">
                      <Option value="house">House</Option>
                      <Option value="apartment">Apartment</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Purpose">
                    <Select placeholder="Select">
                      <Option value="sale">Sale</Option>
                      <Option value="rent">Rent</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Status">
                    <Select placeholder="Select">
                      <Option value="available">Available</Option>
                      <Option value="sold">Sold</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Area">
                    <Select placeholder="Select">
                      <Option value="1000sqft">1000 sqft</Option>
                      <Option value="2000sqft">2000 sqft</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Number of Rooms">
                    <Input type="number" placeholder="Enter number of rooms" />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Furnished Status">
                    <Select placeholder="Select">
                      <Option value="furnished">Furnished</Option>
                      <Option value="unfurnished">Unfurnished</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Construction Year">
                    <Input type="number" placeholder="Enter year" />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Ownership Type">
                    <Select placeholder="Select">
                      <Option value="owned">Owned</Option>
                      <Option value="rented">Rented</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Property ID">
                    <Input placeholder="Enter property ID" />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Landmark">
                    <Select placeholder="Select">
                      <Option value="near park">Near Park</Option>
                      <Option value="city center">City Center</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="Coordinates">
                    <Input placeholder="Latitude, Longitude" />
                  </Form.Item>
                </Col>
              </Row>

              {/* Navigation Buttons */}
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16 }}>
                <Button type="default" disabled>
                  <LeftOutlined /> Back
                </Button>
                <Button type="primary" onClick={handleNext}>
                  Next Step <RightOutlined />
                </Button>
              </div>
            </Form>
          </Card>
        </TabPane>

        {/* Other Steps */}
        {["2", "3", "4", "5", "6"].map((key) => (
          <TabPane tab={<span>{key} {["Address Details", "Pricing", "Amenities", "Documentation", "Media"][key - 2]}</span>} key={key}>
            <Card>
              <p>{["Address Details", "Pricing", "Amenities", "Documentation", "Media"][key - 2]} form will be here...</p>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16 }}>
                <Button type="default" onClick={handleBack}>
                  <LeftOutlined /> Back
                </Button>
                {key !== "6" ? (
                  <Button type="primary" onClick={handleNext}>
                    Next Step <RightOutlined />
                  </Button>
                ) : (
                  <Button type="primary">Finish</Button>
                )}
              </div>
            </Card>
          </TabPane>
        ))}
      </Tabs>
    </div>
  );
};

export default PropertyManager;
