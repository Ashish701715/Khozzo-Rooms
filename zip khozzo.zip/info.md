start : npm run dev
close : control + C
client : ashishboostui@gmail.com
pass : Boost@123